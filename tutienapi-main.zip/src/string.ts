export default {
  unf: "uname not found!",
  ade: "tài khoản không tồn tại!",
  aar: "tài khoản/uname này đã được đăng ký!",
  pnf: "password not found!",
  uunf: "uid not found!",
  lf: "đăng nhập thất bại!",
  ivd: "dữ liệu không hợp lệ!",
  rss: "đăng kí thành công",
  tnf: "token not found!",
  los: "đăng xuất thành công",
  ue: "lỗi không xác định!"
};